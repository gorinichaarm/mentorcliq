<?php

class Matcher
{
	private $matchingCallbacks = [];
	private $data = [];
	private $highestScore = [];

	public function __construct()
	{
		$this->highestScore = array(
			array(0, 0, 0),
			array(0, 0, 0)
		);
	}

	public function setData($data)
	{
		$this->data = $data;
	}

	public function addMatchingCallback($column, $callback)
	{
		$this->matchingCallbacks[$column] = $callback;
	}

	private function runMatchingCallback($row1, $row2)
	{
		$score = 0;

		foreach ($this->matchingCallbacks as $column => $callback) {
			$score += $callback($row1[$column], $row2[$column]);
		}

		return $score;
	}

	private function checkHighestScore($score, $rowIndex1, $rowIndex2)
	{
		if ($score > $this->highestScore[0][0]) {
			$this->highestScore[1] = $this->highestScore[0];
			$this->highestScore[0] = array($score, $rowIndex1, $rowIndex2);
		}
		else if ($score > $this->highestScore[1][0]) {
			$this->highestScore[1] = array($score, $rowIndex1, $rowIndex2);
		}
	}

	public function run()
	{
		for ($i = 1; $i < count($this->data); $i++) {
			for ($j = $i + 1; $j < count($this->data); $j++) {
				$score = $this->runMatchingCallback($this->data[$i], $this->data[$j]);
				$this->checkHighestScore($score, $i, $j);
			}
		}

		return (($this->highestScore[0][0] + $this->highestScore[1][0]) / 2);
	}
}
