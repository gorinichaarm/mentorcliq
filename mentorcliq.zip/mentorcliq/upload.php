<?php
require_once('Matcher.php');

if (isset($_FILES['file'])) {
	$file = $_FILES['file'];

	$fileName = $file['name'];
	$fileTmp = $file['tmp_name'];
	$fileError = $file['error'];

	$fileExtension = explode('.', $fileName);
	$fileExtension = strtolower(end($fileExtension));

	$allowed = array('csv');

	if (in_array($fileExtension, $allowed)) {
		if ($fileError === 0) {
			$matcher = new Matcher();
			// divison
			$matcher->addMatchingCallback(2, function($valueA, $valueB) {
				$result = 0;
				if ($valueA == $valueB) {
					$result = 30;
				}

				return $result;
			});
			// age
			$matcher->addMatchingCallback(3, function($valueA, $valueB) {
				$result = 0;
				if (abs($valueA - $valueB) <= 5) {
					$result = 30;
				}

				return $result;
			});
			// utc
			$matcher->addMatchingCallback(4, function($valueA, $valueB) {
				$result = 0;
				if ($valueA == $valueB) {
					$result = 40;
				}

				return $result;
			});

			$myfile = array_map('str_getcsv', file($fileTmp));
			// simply remove the headers (column names)
			unset($myfile[0]);

			$matcher->setData($myfile);

			echo '<div style="width: 500px;margin: 10% auto;"><h2>The highest average match score is '. $matcher->run() .'%</h2></div>';


		}
	}

}


